"use client";
import { useEffect, useState } from "react";
import ClockPage from "../clock-page";
export default function ClockRoute(){const [token,setToken]=useState("");useEffect(()=>setToken(new URLSearchParams(window.location.search).get("token")||""),[]);return token?<ClockPage token={token}/>:<main className="clock-page"><section className="clock-card"><h1>打卡連結無效</h1><p>請重新掃描店內動態 QR。</p></section></main>}
