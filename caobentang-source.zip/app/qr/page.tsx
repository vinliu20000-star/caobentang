"use client";
import QrDisplayPage from "../qr-page";
export default function Page(){return <QrDisplayPage/>}
