import type { Metadata } from "next";
import "./globals.css";
import "./login.css";

export async function generateMetadata(): Promise<Metadata> {
  return { title: "草本堂｜工時管理", description: "草本堂出勤核對、排班與薪資試算。", icons: { icon: "/favicon.svg" }, openGraph: { title: "草本堂｜工時管理", description: "工時核對・薪資試算，一頁清楚完成。" }, twitter: { card: "summary" } };
}
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="zh-Hant"><body>{children}</body></html>; }
