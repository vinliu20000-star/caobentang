import { env } from "cloudflare:workers";

const allowed = new Set(["https://vinliu20000-star.github.io", "http://localhost:3000"]);
function cors(request:Request){const origin=request.headers.get("Origin")||"";return{"Access-Control-Allow-Origin":allowed.has(origin)?origin:"https://vinliu20000-star.github.io","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"POST, OPTIONS","Vary":"Origin"}}
export async function OPTIONS(request:Request){return new Response(null,{status:204,headers:cors(request)})}
export async function POST(request:Request){
  const vars=env as unknown as {DB:D1Database};
  const body=await request.json() as {challenge?:string};
  const challenge=body.challenge?.trim()||"";
  const valid=await vars.DB.prepare("SELECT token FROM qr_challenges WHERE token = ? AND token LIKE 'q_%' AND expires_at >= ?").bind(challenge,Date.now()).first();
  if(!valid)return Response.json({valid:false,error:"這張 QR 已失效，請掃描店內螢幕最新的 QR"},{status:410,headers:cors(request)});
  const session=`s_${crypto.randomUUID().replaceAll("-","")}`;
  await vars.DB.prepare("INSERT INTO qr_challenges (token, expires_at) VALUES (?, ?)").bind(session,Date.now()+120000).run();
  return Response.json({valid:true,session,expiresIn:120},{headers:cors(request)});
}
