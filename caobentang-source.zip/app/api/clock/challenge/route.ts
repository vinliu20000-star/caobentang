import { env } from "cloudflare:workers";

const allowed = new Set(["https://vinliu20000-star.github.io", "http://localhost:3000"]);
function cors(request:Request){const origin=request.headers.get("Origin")||"";return{"Access-Control-Allow-Origin":allowed.has(origin)?origin:"https://vinliu20000-star.github.io","Access-Control-Allow-Headers":"Authorization","Access-Control-Allow-Methods":"POST, OPTIONS","Vary":"Origin"}}
export async function OPTIONS(request:Request){return new Response(null,{status:204,headers:cors(request)})}
export async function POST(request:Request){
  const vars=env as unknown as Record<string,unknown>&{DB:D1Database};
  if(!vars.SYNC_TOKEN||request.headers.get("Authorization")!==`Bearer ${vars.SYNC_TOKEN}`)return Response.json({error:"Unauthorized"},{status:401,headers:cors(request)});
  const challenge=`q_${crypto.randomUUID().replaceAll("-","")}`;
  await vars.DB.batch([
    vars.DB.prepare("DELETE FROM qr_challenges WHERE token LIKE 'q_%' OR expires_at < ?").bind(Date.now()),
    vars.DB.prepare("INSERT INTO qr_challenges (token, expires_at) VALUES (?, ?)").bind(challenge,Date.now()+18000),
  ]);
  return Response.json({challenge,expiresIn:18},{headers:cors(request)});
}
