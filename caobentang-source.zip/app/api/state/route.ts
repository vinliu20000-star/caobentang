import { env } from "cloudflare:workers";

const allowed = new Set(["https://vinliu20000-star.github.io", "http://localhost:3000"]);
function headers(request: Request) {
  const origin = request.headers.get("Origin") || "";
  return {"Access-Control-Allow-Origin":allowed.has(origin)?origin:"https://vinliu20000-star.github.io","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"GET, PUT, OPTIONS","Vary":"Origin"};
}
function authorized(request: Request, vars: Record<string,string>) { return !!vars.SYNC_TOKEN && request.headers.get("Authorization") === `Bearer ${vars.SYNC_TOKEN}`; }
export async function OPTIONS(request: Request) { return new Response(null,{status:204,headers:headers(request)}); }
export async function GET(request: Request) {
  const vars = env as unknown as Record<string,unknown> & {DB:D1Database};
  if (!authorized(request,vars as unknown as Record<string,string>)) return Response.json({error:"Unauthorized"},{status:401,headers:headers(request)});
  const row = await vars.DB.prepare("SELECT data, updated_at FROM app_state WHERE id = ?").bind(1).first<{data:string;updated_at:string}>();
  return Response.json({state:row?JSON.parse(row.data):null,updatedAt:row?.updated_at||null},{headers:headers(request)});
}
export async function PUT(request: Request) {
  const vars = env as unknown as Record<string,unknown> & {DB:D1Database};
  if (!authorized(request,vars as unknown as Record<string,string>)) return Response.json({error:"Unauthorized"},{status:401,headers:headers(request)});
  const state = await request.json();
  if (!state || !Array.isArray(state.people) || !Array.isArray(state.rows) || !Array.isArray(state.schedules)) return Response.json({error:"Invalid state"},{status:400,headers:headers(request)});
  await vars.DB.prepare("INSERT INTO app_state (id, data, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP").bind(1,JSON.stringify(state)).run();
  return Response.json({ok:true},{headers:headers(request)});
}
