import { env } from "cloudflare:workers";

const allowed = new Set(["https://vinliu20000-star.github.io", "http://localhost:3000"]);
function cors(request: Request) {
  const origin = request.headers.get("Origin") || "";
  return {"Access-Control-Allow-Origin":allowed.has(origin)?origin:"https://vinliu20000-star.github.io","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"POST, OPTIONS","Vary":"Origin"};
}
export async function OPTIONS(request: Request) { return new Response(null,{status:204,headers:cors(request)}); }
export async function POST(request: Request) {
  const vars = env as unknown as Record<string,string>;
  const {password} = await request.json() as {password?:string};
  if (!vars.SYNC_PASSWORD || password !== vars.SYNC_PASSWORD) return Response.json({error:"Unauthorized"},{status:401,headers:cors(request)});
  return Response.json({token:vars.SYNC_TOKEN},{headers:cors(request)});
}
