CREATE TABLE `clock_uses` (
	`challenge` text NOT NULL,
	`person_id` integer NOT NULL,
	`used_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	PRIMARY KEY(`challenge`, `person_id`)
);
--> statement-breakpoint
CREATE TABLE `qr_challenges` (
	`token` text PRIMARY KEY NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
